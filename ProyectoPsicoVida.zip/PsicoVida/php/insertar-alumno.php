<?php
include 'vars.php';

# verificar si vienen los parámetros requeridos
if (empty($_POST["matricula"])) {
    http_response_code(400);
    exit("Falta matrícula"); # Terminar el script definitivamente
}

if (empty($_POST["nombre"])) {
    http_response_code(400);
    exit("Falta nombre"); # Terminar el script definitivamente
}
if (empty($_POST["carrera"])) {
    http_response_code(400);
    exit("Falta carrera"); # Terminar el script definitivamente
}

$conex = new PDO("sqlite:" . $nombre_fichero);
$conex->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$alumno=[
    "matricula"=> $_POST["matricula"],
    "nombre"=> $_POST["nombre"],
    "carrera"=> $_POST["carrera"]
];
try {
    # preparando la consulta
    $sentencia = $conex->prepare("INSERT INTO alumnos (matricula, nombre, carrera) VALUES (:matricula, :nombre, :carrera);");
    $resultado = $sentencia->execute($alumno);
    if ($resultado) {
        http_response_code(200);
        echo "Datos insertados";
        # Redirección y recarga de la página anterior
        header("Refresh: 2; URL={$_SERVER['HTTP_REFERER']}");
        exit();
    }
} catch(PDOException $exc) {
    http_response_code(400);
    echo "Lo siento, ocurrió un error: " . $exc->getMessage();
}

?>
