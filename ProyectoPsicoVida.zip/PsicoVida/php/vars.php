<?php

$nombre_fichero = __DIR__."/citas.sqlite3";

?>